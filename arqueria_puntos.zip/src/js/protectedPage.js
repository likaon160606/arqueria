document.addEventListener('DOMContentLoaded', async () => {
  try {
      const token = localStorage.getItem('token');

      if (!token) {
          alert('Debes iniciar sesión primero.');
          window.location.href = '/'; // Redirige al login si no hay token
          return;
      }

      // Hacer una solicitud a la ruta protegida
      const response = await fetch('/add', {
          method: 'GET',
          headers: {
              Authorization: `Bearer ${token}`,
          },
      });

      if (!response.ok) {
          const errorData = await response.json();
          alert(`Error: ${errorData.message}`);
          window.location.href = '/'; // Redirige si no tiene acceso
          return;
      }

      // Renderiza la vista o realiza acciones adicionales
      const html = await response.text();
      document.body.innerHTML = html; // Inserta el HTML de la respuesta
  } catch (error) {
      console.error('Error al cargar la página:', error);
      alert('Ocurrió un error inesperado.');
  }
});
